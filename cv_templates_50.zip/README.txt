
CV Templates package — 50 HTML + CSS templates
Generated files: 50 templates
Location: root of the ZIP (templates HTML files) and assets/ (styles.css and avatar.svg)

How to use:
1. Download and unzip the package.
2. Upload all files and the assets folder to your Vercel project (static site) root.
   - Each HTML file is a standalone preview page, e.g. /template-01-modern-en.html
3. To make a "builder" page that fills in data into templates you'll need a small JS form to replace text nodes or generate a new HTML from a template.
4. The 'Download PDF' button uses window.print() — works in browser to save as PDF.

File list (first 10 shown):
[
  "template-01-modern-en.html",
  "template-02-minimal-ar.html",
  "template-03-corporate-fr.html",
  "template-04-colorful-tr.html",
  "template-05-classic-en.html",
  "template-06-modern-ar.html",
  "template-07-minimal-fr.html",
  "template-08-corporate-tr.html",
  "template-09-colorful-en.html",
  "template-10-classic-ar.html"
]
